-- Adminer 4.2.4 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE DATABASE `blog` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `blog`;

DROP TABLE IF EXISTS `authors`;
CREATE TABLE `authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `authors` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1,	'John Smith',	'2016-03-05 07:06:15',	'2016-03-05 07:06:15'),
(2,	'Joe Smith',	'2016-03-05 07:06:35',	'2016-03-05 07:06:35'),
(3,	'Bob Smith',	'2016-03-05 07:06:45',	'2016-03-05 07:06:45'),
(4,	'Mike Smith',	'2016-03-05 07:06:56',	'2016-03-05 07:06:56'),
(5,	'Juan Carlos',	'2016-03-05 07:07:09',	'2016-03-05 07:07:09'),
(6,	'Jane Smith',	'2016-03-05 07:07:20',	'2016-03-05 07:07:20'),
(7,	'Mike Jones',	'2016-03-05 07:07:31',	'2016-03-05 07:07:31'),
(8,	'David Smith',	'2016-03-05 07:07:40',	'2016-03-05 07:07:40'),
(9,	'Sarah Smith',	'2016-03-05 07:07:50',	'2016-03-05 07:07:50'),
(10,	'James Smith',	'2016-03-05 07:08:03',	'2016-03-05 07:08:03'),
(11,	'Nicole Smith',	'2016-03-05 07:10:11',	'2016-03-05 07:10:11');

DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `author_id` int(11) NOT NULL COMMENT 'Id of author who added comment.',
  `post_id` int(11) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  KEY `post_id` (`post_id`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`),
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `comments` (`id`, `content`, `author_id`, `post_id`, `created_at`, `updated_at`) VALUES
(1,	'Cool.',	2,	1,	'2016-03-05 07:13:15',	'2016-03-05 07:13:15'),
(2,	'Nice one. Thanks.',	9,	1,	'2016-03-05 07:13:31',	'2016-03-05 07:13:31'),
(3,	'Interesting.',	1,	3,	'2016-03-05 07:13:46',	'2016-03-05 07:13:46'),
(4,	'Nice to learn.',	5,	2,	'2016-03-05 07:15:07',	'2016-03-05 07:15:07');

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `author_id` int(11) NOT NULL,
  `emails_sent` int(11) unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `author_id` (`author_id`),
  CONSTRAINT `posts_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `authors` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `posts` (`id`, `title`, `content`, `author_id`, `emails_sent`, `created_at`, `updated_at`) VALUES
(1,	'Intro to PHP7',	'Sample content for PHP7.',	1,	0,	'2016-03-05 07:11:51',	'2016-03-05 07:11:51'),
(2,	'Python tutorial',	'Sample python content',	2,	1,	'2016-03-05 07:12:20',	'2016-03-05 07:12:20'),
(3,	'MySQL Optimization',	'Sample MySQL content.',	3,	0,	'2016-03-05 07:12:46',	'2016-03-05 07:12:46'),
(4,	'My Random Post',	'Content',	1,	0,	'2016-03-21 09:55:12',	'2016-03-21 09:55:12'),
(5,	'My Random Post',	'Content',	1,	0,	'2016-03-21 09:55:44',	'2016-03-21 09:55:44'),
(6,	'My Random Post',	'Content',	1,	0,	'2016-03-25 08:51:57',	'2016-03-25 08:51:57'),
(7,	'My Random Post',	'Content',	1,	0,	'2016-03-25 08:54:14',	'2016-03-25 08:54:14'),
(8,	'My Random Post',	'Content',	1,	0,	'2016-03-25 08:55:10',	'2016-03-25 08:55:10'),
(9,	'My Random Post',	'Content',	1,	0,	'2016-03-25 09:01:42',	'2016-03-25 09:01:42'),
(10,	'My Random Post',	'Content',	1,	0,	'2016-03-25 09:07:14',	'2016-03-25 09:07:14'),
(15,	'My Random Post',	'Content',	1,	0,	'2016-03-25 13:45:26',	'2016-03-25 13:45:26');

-- 2016-03-27 06:31:05
